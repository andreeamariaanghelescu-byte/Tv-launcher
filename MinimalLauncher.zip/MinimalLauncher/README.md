# Minimal Launcher v2 (Android TV, Android 5.0+)

Ceas, data, Wi-Fi, setari, cautare, vreme, calendar, SURSE (TV Channels, AV, HDMI 1, HDMI 2),
YouTube / Netflix, clipuri YouTube si meniul de aplicatii.

- Fundal colorat: butonul cu 4 puncte colorate din dreapta sus schimba culorile.
- Surse: daca una nu porneste, tine apasat OK pe ea si alege intrarea sau aplicatia potrivita.
- Vreme: tine apasat OK pe card ca sa alegi orasul.
- Clipuri YouTube: canalele se schimba in MainActivity.java (lista YT_CHANNELS).
