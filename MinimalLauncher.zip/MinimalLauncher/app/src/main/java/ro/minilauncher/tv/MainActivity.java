package ro.minilauncher.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.tv.TvInputInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Lansator minimalist pentru Android TV (Android 5.0+).
 * Ceas, dată, Wi-Fi, setări, căutare, vreme, calendar, surse TV,
 * YouTube / Netflix, clipuri YouTube și meniul de aplicații.
 *
 * Toate dimensiunile sunt gândite pentru 1920 px lățime și se scalează automat.
 */
public class MainActivity extends Activity {

    private static final int COLUMNS = 6;
    private static final Locale RO = new Locale("ro", "RO");

    // Canale YouTube de unde se iau clipurile (ID-uri de canal; le poți schimba).
    // Dacă un canal nu răspunde, este pur și simplu ignorat.
    private static final String[] YT_CHANNELS = {
            "UCAuUUnT6oDeKwE6v1NGQxug", // TED
            "UCpVm7bg6pXKo1Pr6k5kxG9A", // National Geographic
            "UCsXVk37bltHxD1rDPwtNM8Q", // Kurzgesagt
            "UCHnyfMqiRRG1u-2MsSQLbXA", // Veritasium
            "UC16niRr50-MSBwiO3YDb3RA"  // BBC News
    };

    private static final String[] CITY_NAMES = {
            "București", "Cluj-Napoca", "Timișoara", "Iași", "Constanța", "Brașov",
            "Craiova", "Galați", "Ploiești", "Oradea", "Sibiu", "Pitești",
            "Bacău", "Arad", "Suceava", "Târgu Mureș"
    };
    private static final double[][] CITY_COORDS = {
            {44.43, 26.10}, {46.77, 23.59}, {45.75, 21.23}, {47.16, 27.59},
            {44.18, 28.65}, {45.65, 25.61}, {44.32, 23.80}, {45.43, 28.05},
            {44.94, 26.03}, {47.05, 21.93}, {45.80, 24.15}, {44.86, 24.87},
            {46.57, 26.91}, {46.18, 21.31}, {47.65, 26.26}, {46.54, 24.56}
    };

    private static class AppItem {
        String label;
        Drawable icon;
        String pkg;
        String cls;
    }

    private float scale;
    private int contentWidth;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private boolean alive = true;
    private boolean receiverOn = false;

    private ScrollView scroll;
    private WallpaperView wallpaper;
    private TextView clockView;
    private TextView dateView;
    private IconView wifiIcon;
    private View searchCard;
    private TextView weatherTemp;
    private TextView weatherDesc;
    private TextView weatherCity;
    private LinearLayout calendarBox;
    private LinearLayout clipsRow;
    private LinearLayout appsContainer;

    private final List<AppItem> allApps = new ArrayList<AppItem>();
    private String lastSignature = "";
    private int lastDay = -1;
    private long lastFetch = 0;

    private final View.OnFocusChangeListener zoom = new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            float z = hasFocus ? 1.05f : 1f;
            v.animate().scaleX(z).scaleY(z).setDuration(120).start();
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateClock();
            handler.postDelayed(this, 5000);
        }
    };

    private final BroadcastReceiver netReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateNetwork();
        }
    };

    // ------------------------------------------------------------------
    // Ciclul de viață
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        scale = getResources().getDisplayMetrics().widthPixels / 1920f;
        int side = s(80);
        contentWidth = getResources().getDisplayMetrics().widthPixels - 2 * side;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF101218);

        wallpaper = new WallpaperView(this);
        wallpaper.setPalette(prefs.getInt("palette", 0));
        root.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));

        // Opțional: res/drawable-nodpi/wallpaper.jpg înlocuiește fundalul generat
        int wid = getResources().getIdentifier("wallpaper", "drawable", getPackageName());
        if (wid != 0) {
            ImageView wp = new ImageView(this);
            wp.setScaleType(ImageView.ScaleType.CENTER_CROP);
            wp.setImageResource(wid);
            root.addView(wp, new FrameLayout.LayoutParams(-1, -1));
            View shade = new View(this);
            shade.setBackgroundColor(0x66000000);
            root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        }

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setClipChildren(false);
        scroll.setClipToPadding(false);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(side, s(40), side, s(60));
        content.setClipChildren(false);
        scroll.addView(content, new FrameLayout.LayoutParams(-1, -2));

        buildHeader(content);
        buildWidgets(content);
        buildSources(content);
        buildStreaming(content);
        buildClips(content);

        content.addView(sectionLabel("APLICAȚII"));
        appsContainer = new LinearLayout(this);
        appsContainer.setOrientation(LinearLayout.VERTICAL);
        appsContainer.setClipChildren(false);
        content.addView(appsContainer);

        setContentView(root);
        searchCard.requestFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        if (!receiverOn) {
            registerReceiver(netReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
            receiverOn = true;
        }
        updateNetwork();
        handler.removeCallbacks(tick);
        handler.post(tick);
        long now = System.currentTimeMillis();
        if (now - lastFetch > 15 * 60 * 1000L) {
            lastFetch = now;
            fetchWeather();
            loadClips();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
        if (receiverOn) {
            try {
                unregisterReceiver(netReceiver);
            } catch (Exception ignored) {
                // deja dezactivat
            }
            receiverOn = false;
        }
    }

    @Override
    protected void onDestroy() {
        alive = false;
        pool.shutdownNow();
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        scroll.scrollTo(0, 0);
        if (searchCard != null) searchCard.requestFocus();
    }

    @Override
    public void onBackPressed() {
        // Lansatorul nu se închide cu Back
    }

    // ------------------------------------------------------------------
    // Construirea ecranului
    // ------------------------------------------------------------------

    private void buildHeader(LinearLayout content) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setClipChildren(false);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        clockView = text("--:--", 96, 0xFFFFFFFF);
        clockView.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        dateView = text("", 30, 0xCCFFFFFF);
        left.addView(clockView);
        left.addView(dateView);
        header.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));

        wifiIcon = new IconView(this);
        wifiIcon.setType(IconView.WIFI_OFF);
        header.addView(iconButton(wifiIcon, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWifiSettings();
            }
        }));

        IconView palette = new IconView(this);
        palette.setType(IconView.PALETTE);
        header.addView(iconButton(palette, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int next = (prefs.getInt("palette", 0) + 1) % WallpaperView.PALETTES.length;
                prefs.edit().putInt("palette", next).apply();
                wallpaper.setPalette(next);
            }
        }));

        IconView gear = new IconView(this);
        gear.setType(IconView.GEAR);
        header.addView(iconButton(gear, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettings();
            }
        }));

        content.addView(header, new LinearLayout.LayoutParams(-1, -2));
    }

    private void buildWidgets(LinearLayout content) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);

        // Căutare
        LinearLayout search = card(3f);
        search.setGravity(Gravity.CENTER);
        IconView si = new IconView(this);
        si.setType(IconView.SEARCH);
        search.addView(si, new LinearLayout.LayoutParams(s(80), s(80)));
        TextView st = text("Caută pe internet", 34, 0xFFFFFFFF);
        st.setTypeface(Typeface.DEFAULT_BOLD);
        st.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stl = new LinearLayout.LayoutParams(-2, -2);
        stl.topMargin = s(14);
        search.addView(st, stl);
        TextView sh = text("Apasă OK și scrie", 24, 0x99FFFFFF);
        sh.setGravity(Gravity.CENTER);
        search.addView(sh);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSearch();
            }
        });
        searchCard = search;
        row.addView(search);

        // Vreme
        LinearLayout weather = card(2f);
        weather.setGravity(Gravity.CENTER);
        weatherTemp = text("--°", 88, 0xFFFFFFFF);
        weatherTemp.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        weatherDesc = text("Se încarcă…", 28, 0xFFFFFFFF);
        weatherCity = text(CITY_NAMES[prefs.getInt("city", 0)], 24, 0x99FFFFFF);
        weather.addView(weatherTemp);
        weather.addView(weatherDesc);
        weather.addView(weatherCity);
        weather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchWeather();
            }
        });
        weather.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showCityPicker();
                return true;
            }
        });
        row.addView(weather);

        // Calendar
        calendarBox = card(3f);
        calendarBox.setPadding(s(20), s(14), s(20), s(14));
        calendarBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCalendarApp();
            }
        });
        row.addView(calendarBox);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, s(290));
        lp.topMargin = s(30);
        content.addView(row, lp);
    }

    private void buildSources(LinearLayout content) {
        content.addView(sectionLabel("SURSE"));
        LinearLayout row = newRow();
        for (int i = 0; i < Sources.NAMES.length; i++) {
            final int kind = i;
            LinearLayout t = tile(Sources.NAMES[i], null, s(120), 0x1AFFFFFF, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String err = Sources.open(MainActivity.this, kind);
                    if (err != null) toast(err);
                }
            });
            t.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showSourcePicker(kind);
                    return true;
                }
            });
            row.addView(t);
        }
        content.addView(row);

        TextView hint = text("Dacă o sursă nu pornește: ține apăsat OK pe ea și alege intrarea sau aplicația potrivită.",
                20, 0x80FFFFFF);
        hint.setPadding(s(8), s(6), 0, 0);
        content.addView(hint);
    }

    private void buildStreaming(LinearLayout content) {
        content.addView(sectionLabel("STREAMING"));
        LinearLayout row = newRow();

        LinearLayout yt = tile("YouTube", null, s(120), 0x55E62117, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFirstInstalled(new String[]{"com.google.android.youtube.tv",
                        "com.google.android.youtube"}, "YouTube");
            }
        });
        row.addView(yt);

        LinearLayout nf = tile("Netflix", null, s(120), 0x55B20710, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFirstInstalled(new String[]{"com.netflix.ninja",
                        "com.netflix.mediaclient"}, "Netflix");
            }
        });
        row.addView(nf);
        content.addView(row);
    }

    private void buildClips(LinearLayout content) {
        content.addView(sectionLabel("CLIPURI YOUTUBE"));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setOverScrollMode(View.OVER_SCROLL_NEVER);
        hs.setClipChildren(false);
        hs.setClipToPadding(false);
        clipsRow = new LinearLayout(this);
        clipsRow.setOrientation(LinearLayout.HORIZONTAL);
        clipsRow.setClipChildren(false);
        hs.addView(clipsRow, new FrameLayout.LayoutParams(-2, -2));
        content.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        showClipsMessage("Se încarcă clipurile…");
    }

    // ------------------------------------------------------------------
    // Ceas, dată, rețea
    // ------------------------------------------------------------------

    private void updateClock() {
        Date now = new Date();
        clockView.setText(new SimpleDateFormat("HH:mm", RO).format(now));
        String d = new SimpleDateFormat("EEEE, d MMMM yyyy", RO).format(now);
        if (d.length() > 0) d = d.substring(0, 1).toUpperCase(RO) + d.substring(1);
        dateView.setText(d);
        int day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
        if (day != lastDay) {
            lastDay = day;
            buildCalendar();
        }
    }

    private void updateNetwork() {
        int type = IconView.WIFI_OFF;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = (cm == null) ? null : cm.getActiveNetworkInfo();
            if (ni != null && ni.isConnected()) {
                type = (ni.getType() == ConnectivityManager.TYPE_ETHERNET)
                        ? IconView.ETHERNET : IconView.WIFI;
            }
        } catch (Exception ignored) {
            // rămâne pictograma "fără rețea"
        }
        wifiIcon.setType(type);
    }

    private void buildCalendar() {
        calendarBox.removeAllViews();
        Calendar cal = Calendar.getInstance();
        int today = cal.get(Calendar.DAY_OF_MONTH);

        String title = new SimpleDateFormat("MMMM yyyy", RO).format(cal.getTime());
        if (title.length() > 0) title = title.substring(0, 1).toUpperCase(RO) + title.substring(1);
        TextView tv = text(title, 24, 0xFFFFFFFF);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        calendarBox.addView(tv);

        String[] wd = {"L", "M", "M", "J", "V", "S", "D"};
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        for (String w : wd) {
            head.addView(calCell(w, 0x99FFFFFF, false));
        }
        calendarBox.addView(head, new LinearLayout.LayoutParams(-1, s(28)));

        Calendar first = (Calendar) cal.clone();
        first.set(Calendar.DAY_OF_MONTH, 1);
        int offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7; // luni = 0
        int days = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        int cells = offset + days;
        int rows = (cells + 6) / 7;
        int day = 1;
        for (int r = 0; r < rows; r++) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 7; c++) {
                int idx = r * 7 + c;
                if (idx < offset || day > days) {
                    line.addView(calCell("", 0, false));
                } else {
                    boolean isToday = (day == today);
                    line.addView(calCell(String.valueOf(day), isToday ? 0xFF101218 : 0xFFFFFFFF, isToday));
                    day++;
                }
            }
            calendarBox.addView(line, new LinearLayout.LayoutParams(-1, s(30)));
        }
    }

    private TextView calCell(String t, int color, boolean highlight) {
        TextView c = text(t, 20, color);
        c.setGravity(Gravity.CENTER);
        if (highlight) {
            GradientDrawable oval = new GradientDrawable();
            oval.setShape(GradientDrawable.OVAL);
            oval.setColor(0xFFFFFFFF);
            c.setBackground(oval);
            c.setTypeface(Typeface.DEFAULT_BOLD);
        }
        c.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1f));
        return c;
    }

    // ------------------------------------------------------------------
    // Vreme
    // ------------------------------------------------------------------

    private void fetchWeather() {
        final int city = prefs.getInt("city", 0);
        weatherCity.setText(CITY_NAMES[city]);
        pool.execute(new Runnable() {
            @Override
            public void run() {
                String temp;
                String desc;
                try {
                    double[] w = Net.weather(CITY_COORDS[city][0], CITY_COORDS[city][1]);
                    temp = Math.round(w[0]) + "°";
                    desc = Net.weatherText((int) w[1]);
                } catch (Exception e) {
                    temp = "--°";
                    desc = "Fără date (internet?)";
                }
                final String t = temp;
                final String d = desc;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!alive) return;
                        weatherTemp.setText(t);
                        weatherDesc.setText(d);
                    }
                });
            }
        });
    }

    private void showCityPicker() {
        new AlertDialog.Builder(this)
                .setTitle("Alege orașul pentru vreme")
                .setItems(CITY_NAMES, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.edit().putInt("city", which).apply();
                        fetchWeather();
                    }
                })
                .show();
    }

    // ------------------------------------------------------------------
    // Clipuri YouTube
    // ------------------------------------------------------------------

    private void loadClips() {
        pool.execute(new Runnable() {
            @Override
            public void run() {
                List<List<Net.Video>> per = new ArrayList<List<Net.Video>>();
                for (String ch : YT_CHANNELS) {
                    try {
                        per.add(Net.youtube(ch, 3));
                    } catch (Exception ignored) {
                        // canal indisponibil, îl sărim
                    }
                }
                final List<Net.Video> all = new ArrayList<Net.Video>();
                for (int k = 0; k < 3; k++) {
                    for (List<Net.Video> l : per) {
                        if (k < l.size()) all.add(l.get(k));
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (alive) showClips(all);
                    }
                });
            }
        });
    }

    private void showClipsMessage(String msg) {
        clipsRow.removeAllViews();
        TextView t = text(msg, 24, 0x99FFFFFF);
        t.setPadding(s(8), s(10), 0, s(10));
        clipsRow.addView(t);
    }

    private void showClips(List<Net.Video> videos) {
        if (videos.isEmpty()) {
            showClipsMessage("Nu am putut încărca clipurile. Verifică conexiunea la internet.");
            return;
        }
        clipsRow.removeAllViews();
        for (final Net.Video v : videos) {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setPadding(s(10), s(10), s(10), s(10));
            c.setBackground(tileBackground(0x1AFFFFFF, 18));
            c.setFocusable(true);
            c.setClickable(true);
            c.setOnFocusChangeListener(zoom);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    playVideo(v.id);
                }
            });

            final ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundColor(0x33000000);
            c.addView(iv, new LinearLayout.LayoutParams(s(320), s(180)));

            TextView title = text(v.title == null ? "" : v.title, 22, 0xFFFFFFFF);
            title.setMaxLines(2);
            title.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(s(320), -2);
            tl.topMargin = s(8);
            c.addView(title, tl);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(s(8), s(8), s(8), s(8));
            clipsRow.addView(c, lp);

            final String thumb = "https://i.ytimg.com/vi/" + v.id + "/mqdefault.jpg";
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        final Bitmap b = Net.bitmap(thumb);
                        if (b == null) return;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (alive) iv.setImageBitmap(b);
                            }
                        });
                    } catch (Exception ignored) {
                        // fără miniatură
                    }
                }
            });
        }
    }

    private void playVideo(String id) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + id)));
            return;
        } catch (Exception ignored) {
            // încercăm linkul web
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/watch?v=" + id)));
        } catch (Exception e) {
            toast("Nu am găsit aplicația YouTube sau un browser.");
        }
    }

    private void openFirstInstalled(String[] packages, String name) {
        for (String pkg : packages) {
            Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
            if (li != null) {
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    startActivity(li);
                    return;
                } catch (Exception ignored) {
                    // încercăm următorul pachet
                }
            }
        }
        try {
            Intent store = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packages[0]));
            store.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(store);
        } catch (Exception e) {
            toast(name + " nu este instalat pe acest televizor.");
        }
    }

    // ------------------------------------------------------------------
    // Căutare, setări, calendar
    // ------------------------------------------------------------------

    private void showSearch() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("Ce cauți?");
        et.setImeOptions(EditorInfo.IME_ACTION_SEARCH);

        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Caută pe Google")
                .setView(et)
                .setPositiveButton("Caută", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        doSearch(et.getText().toString());
                    }
                })
                .setNegativeButton("Anulează", null)
                .create();

        et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                    dlg.dismiss();
                    doSearch(et.getText().toString());
                    return true;
                }
                return false;
            }
        });
        dlg.show();
    }

    private void doSearch(String q) {
        q = q.trim();
        if (q.length() == 0) return;
        try {
            String url = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8");
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Nu există browser pe televizor. Instalează unul (de ex. TV Bro sau Puffin TV).");
        }
    }

    private void openSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return;
        } catch (Exception ignored) {
            // încercăm varianta Android TV
        }
        try {
            Intent i = new Intent();
            i.setClassName("com.android.tv.settings", "com.android.tv.settings.MainSettings");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Nu pot deschide setările televizorului.");
        }
    }

    private void openWifiSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_WIFI_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            openSettings();
        }
    }

    private void openCalendarApp() {
        try {
            Intent i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Nu există o aplicație Calendar pe acest televizor.");
        }
    }

    // ------------------------------------------------------------------
    // Alegerea manuală a sursei (ține apăsat OK)
    // ------------------------------------------------------------------

    private void showSourcePicker(final int kind) {
        final List<String> labels = new ArrayList<String>();
        final List<String> values = new ArrayList<String>();
        labels.add("Automat (implicit)");
        values.add("");

        for (TvInputInfo i : Sources.inputs(this)) {
            String id = i.getId();
            int slash = id.lastIndexOf('/');
            String shortId = (slash >= 0) ? id.substring(slash + 1) : id;
            labels.add("Intrare: " + i.loadLabel(this) + "  [" + Sources.typeName(i.getType())
                    + (i.isPassthroughInput() ? "" : ", fără passthrough") + "]  " + shortId);
            values.add("in:" + id);
        }
        for (AppItem a : allApps) {
            labels.add("Aplicație: " + a.label);
            values.add("app:" + a.pkg + "/" + a.cls);
        }

        new AlertDialog.Builder(this)
                .setTitle("Alege pentru: " + Sources.NAMES[kind])
                .setItems(labels.toArray(new String[labels.size()]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String v = values.get(which);
                        if (v.length() == 0) {
                            prefs.edit().remove("src" + kind).apply();
                            toast("Sursa " + Sources.NAMES[kind] + ": automat.");
                        } else {
                            prefs.edit().putString("src" + kind, v).apply();
                            toast("Salvat. Apasă acum pe " + Sources.NAMES[kind] + " ca să testezi.");
                        }
                    }
                })
                .show();
    }

    // ------------------------------------------------------------------
    // Aplicații
    // ------------------------------------------------------------------

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Map<String, ResolveInfo> found = new LinkedHashMap<String, ResolveInfo>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName())) continue;
                if (!found.containsKey(pkg)) found.put(pkg, ri);
            }
        }

        StringBuilder sig = new StringBuilder();
        for (String pkg : found.keySet()) sig.append(pkg).append(';');
        if (sig.toString().equals(lastSignature)) return; // nimic nou, păstrăm focusul
        lastSignature = sig.toString();

        allApps.clear();
        for (ResolveInfo ri : found.values()) {
            AppItem it = new AppItem();
            it.label = String.valueOf(ri.loadLabel(pm));
            it.icon = ri.loadIcon(pm);
            it.pkg = ri.activityInfo.packageName;
            it.cls = ri.activityInfo.name;
            allApps.add(it);
        }
        Collections.sort(allApps, new Comparator<AppItem>() {
            @Override
            public int compare(AppItem a, AppItem b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });

        appsContainer.removeAllViews();
        LinearLayout row = null;
        for (int i = 0; i < allApps.size(); i++) {
            if (i % COLUMNS == 0) {
                row = newRow();
                appsContainer.addView(row);
            }
            final AppItem it = allApps.get(i);
            row.addView(tile(it.label, it.icon, s(170), 0x1AFFFFFF, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String err = Sources.launchApp(MainActivity.this, it.pkg + "/" + it.cls);
                    if (err != null) toast(err);
                }
            }));
        }
    }

    // ------------------------------------------------------------------
    // Ajutoare pentru interfață
    // ------------------------------------------------------------------

    private LinearLayout tile(String label, Drawable icon, int heightPx, int fill, View.OnClickListener click) {
        int w = contentWidth / COLUMNS;

        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(s(10), s(10), s(10), s(10));
        t.setBackground(tileBackground(fill, 20));
        t.setFocusable(true);
        t.setClickable(true);
        t.setOnClickListener(click);
        t.setOnFocusChangeListener(zoom);

        if (icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(icon);
            t.addView(iv, new LinearLayout.LayoutParams(s(80), s(80)));
        }

        TextView tv = text(label, icon != null ? 22 : 32, 0xFFFFFFFF);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        if (icon == null) tv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        if (icon != null) tlp.topMargin = s(10);
        t.addView(tv, tlp);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w - s(16), heightPx);
        lp.setMargins(s(8), s(8), s(8), s(8));
        t.setLayoutParams(lp);
        return t;
    }

    /** Card de widget (ocupă o parte din rând, după pondere). */
    private LinearLayout card(float weight) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(s(24), s(20), s(24), s(20));
        c.setBackground(tileBackground(0x26FFFFFF, 28));
        c.setFocusable(true);
        c.setClickable(true);
        c.setClipChildren(false);
        c.setOnFocusChangeListener(zoom);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, weight);
        lp.setMargins(s(8), s(8), s(8), s(8));
        c.setLayoutParams(lp);
        return c;
    }

    private LinearLayout iconButton(IconView icon, View.OnClickListener click) {
        LinearLayout b = new LinearLayout(this);
        b.setGravity(Gravity.CENTER);
        b.setBackground(tileBackground(0x26FFFFFF, 40));
        b.setFocusable(true);
        b.setClickable(true);
        b.setOnClickListener(click);
        b.setOnFocusChangeListener(zoom);
        b.addView(icon, new LinearLayout.LayoutParams(s(46), s(46)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s(80), s(80));
        lp.leftMargin = s(18);
        b.setLayoutParams(lp);
        return b;
    }

    private Drawable tileBackground(int fill, int radius) {
        GradientDrawable focused = new GradientDrawable();
        focused.setColor(0x4DFFFFFF);
        focused.setCornerRadius(s(radius));
        focused.setStroke(s(3), 0xF2FFFFFF);

        GradientDrawable normal = new GradientDrawable();
        normal.setColor(fill);
        normal.setCornerRadius(s(radius));

        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, focused);
        sl.addState(new int[]{android.R.attr.state_pressed}, focused);
        sl.addState(new int[]{}, normal);
        return sl;
    }

    private LinearLayout newRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        return row;
    }

    private TextView sectionLabel(String t) {
        TextView tv = text(t, 22, 0xB3FFFFFF);
        tv.setLetterSpacing(0.15f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(s(8), s(40), 0, s(8));
        return tv;
    }

    private TextView text(String t, int sizePx, int color) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextColor(color);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, s(sizePx));
        return tv;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    /** Convertește pixeli de design (la 1920 lățime) în pixeli reali. */
    private int s(int v) {
        return Math.round(v * scale);
    }
}
