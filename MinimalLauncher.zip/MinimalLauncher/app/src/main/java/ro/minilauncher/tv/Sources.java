package ro.minilauncher.tv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.Uri;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Comutarea surselor TV (TV Channels, AV, HDMI 1, HDMI 2).
 * Funcțiile întorc null la succes sau un mesaj de eroare (în română).
 *
 * Ordinea încercărilor:
 *  1. sursa aleasă manual de utilizator (ține apăsat pe tile);
 *  2. detectare automată prin TV Input Framework (Android TV standard);
 *  3. aplicația TV a producătorului (căutată după nume/pachet).
 */
final class Sources {
    private Sources() {
    }

    static final int TV = 0;
    static final int AV = 1;
    static final int HDMI1 = 2;
    static final int HDMI2 = 3;
    static final String[] NAMES = {"TV Channels", "AV", "HDMI 1", "HDMI 2"};

    // ------------------------------------------------------------------
    // Intrări TV
    // ------------------------------------------------------------------

    static List<TvInputInfo> inputs(Context c) {
        try {
            TvInputManager tm = (TvInputManager) c.getSystemService(Context.TV_INPUT_SERVICE);
            if (tm != null) {
                List<TvInputInfo> l = tm.getTvInputList();
                if (l != null) return l;
            }
        } catch (Exception ignored) {
            // niciun TV Input Framework disponibil
        }
        return new ArrayList<TvInputInfo>();
    }

    static String typeName(int t) {
        if (t == TvInputInfo.TYPE_TUNER) return "TUNER";
        if (t == TvInputInfo.TYPE_HDMI) return "HDMI";
        if (t == TvInputInfo.TYPE_COMPOSITE) return "AV";
        if (t == TvInputInfo.TYPE_SVIDEO) return "S-VIDEO";
        if (t == TvInputInfo.TYPE_SCART) return "SCART";
        if (t == TvInputInfo.TYPE_COMPONENT) return "COMPONENT";
        if (t == TvInputInfo.TYPE_VGA) return "VGA";
        if (t == TvInputInfo.TYPE_DVI) return "DVI";
        if (t == TvInputInfo.TYPE_DISPLAY_PORT) return "DISPLAYPORT";
        return "ALTELE";
    }

    private static TvInputInfo byId(Context c, String id) {
        for (TvInputInfo i : inputs(c)) {
            if (i.getId().equals(id)) return i;
        }
        return null;
    }

    private static TvInputInfo autoFind(Context c, int kind) {
        List<TvInputInfo> hdmi = new ArrayList<TvInputInfo>();
        TvInputInfo av = null;
        for (TvInputInfo info : inputs(c)) {
            if (!info.isPassthroughInput()) continue;
            int type = info.getType();
            if (type == TvInputInfo.TYPE_HDMI) {
                hdmi.add(info);
            } else if (av == null && (type == TvInputInfo.TYPE_COMPOSITE
                    || type == TvInputInfo.TYPE_SVIDEO
                    || type == TvInputInfo.TYPE_COMPONENT
                    || type == TvInputInfo.TYPE_SCART)) {
                av = info;
            }
        }
        if (kind == AV) return av;

        Collections.sort(hdmi, new Comparator<TvInputInfo>() {
            @Override
            public int compare(TvInputInfo a, TvInputInfo b) {
                return a.getId().compareTo(b.getId());
            }
        });
        int n = (kind == HDMI1) ? 1 : 2;
        for (TvInputInfo info : hdmi) {
            String label = String.valueOf(info.loadLabel(c)).replace(" ", "").toLowerCase(Locale.ROOT);
            if (label.contains("hdmi" + n)) return info;
        }
        if (hdmi.size() >= n) return hdmi.get(n - 1);
        return null;
    }

    // ------------------------------------------------------------------
    // Punct de intrare
    // ------------------------------------------------------------------

    static String open(Activity a, int kind) {
        SharedPreferences sp = a.getSharedPreferences("launcher", Context.MODE_PRIVATE);
        String saved = sp.getString("src" + kind, null);
        if (saved != null) {
            if (saved.startsWith("app:")) {
                return launchApp(a, saved.substring(4));
            }
            if (saved.startsWith("in:")) {
                TvInputInfo info = byId(a, saved.substring(3));
                if (info == null) {
                    return "Sursa salvată nu mai există. Ține apăsat OK pe tile ca s-o alegi din nou.";
                }
                return openInput(a, info);
            }
        }
        if (kind == TV) return openLiveTv(a);
        TvInputInfo info = autoFind(a, kind);
        if (info == null) {
            return "Nu am găsit această sursă automat. Ține apăsat OK pe ea ca s-o alegi manual.";
        }
        return openInput(a, info);
    }

    private static String openInput(Activity a, TvInputInfo info) {
        if (info.getType() == TvInputInfo.TYPE_TUNER) {
            return openLiveTv(a);
        }
        Uri uri = TvContract.buildChannelUriForPassthroughInput(info.getId());

        // 1. intent standard
        String err = view(a, new Intent(Intent.ACTION_VIEW, uri), null);
        if (err == null) return null;

        // 2. același intent, trimis direct aplicației TV a producătorului
        String tvPkg = findLiveTvPackage(a);
        if (tvPkg != null && view(a, new Intent(Intent.ACTION_VIEW, uri), tvPkg) == null) {
            return null;
        }

        // 3. pornim măcar aplicația care deține intrarea
        try {
            String pkg = info.getServiceInfo().packageName;
            Intent li = a.getPackageManager().getLaunchIntentForPackage(pkg);
            if (li != null) {
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                a.startActivity(li);
                return null;
            }
        } catch (Exception ignored) {
            // trecem la mesajul de eroare
        }
        return "Nu am putut comuta sursa (" + err + "). Ține apăsat OK pe tile ca s-o alegi manual.";
    }

    static String openLiveTv(Activity a) {
        // 1. Live TV standard Android TV
        if (view(a, new Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI), null) == null) {
            return null;
        }
        // 2. aplicația TV a producătorului
        String pkg = findLiveTvPackage(a);
        if (pkg != null) {
            String err = launchApp(a, pkg);
            if (err == null) return null;
        }
        // 3. aplicația care deține tunerul
        for (TvInputInfo info : inputs(a)) {
            if (info.getType() == TvInputInfo.TYPE_TUNER) {
                try {
                    Intent li = a.getPackageManager()
                            .getLaunchIntentForPackage(info.getServiceInfo().packageName);
                    if (li != null) {
                        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        a.startActivity(li);
                        return null;
                    }
                } catch (Exception ignored) {
                    // continuăm
                }
            }
        }
        return "Nu am găsit aplicația TV. Ține apăsat OK pe TV Channels ca să alegi aplicația televizorului.";
    }

    // ------------------------------------------------------------------
    // Utilitare
    // ------------------------------------------------------------------

    private static String view(Activity a, Intent i, String pkg) {
        try {
            if (pkg != null) i.setPackage(pkg);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
            return null;
        } catch (Exception e) {
            return e.getClass().getSimpleName();
        }
    }

    /** Pornește o aplicație: "pachet/clasa" sau doar "pachet". */
    static String launchApp(Activity a, String spec) {
        try {
            int s = spec.indexOf('/');
            Intent i;
            if (s > 0) {
                i = new Intent(Intent.ACTION_MAIN);
                i.setClassName(spec.substring(0, s), spec.substring(s + 1));
            } else {
                i = a.getPackageManager().getLaunchIntentForPackage(spec);
                if (i == null) return "Aplicația nu poate fi pornită.";
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            a.startActivity(i);
            return null;
        } catch (Exception e) {
            return "Nu pot porni aplicația.";
        }
    }

    /** Caută aplicația TV a producătorului după nume/pachet. */
    static String findLiveTvPackage(Context c) {
        PackageManager pm = c.getPackageManager();
        String[] keys = {"livetv", "tvcenter", "wwtv", "com.android.tv", "com.google.android.tv",
                "tvapp", "tvplayer"};
        String[] labels = {"tv", "live tv", "live channels", "televizor", "canale tv", "tv live"};
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN);
            q.addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String realPkg = ri.activityInfo.packageName;
                if (realPkg.equals(c.getPackageName())) continue;
                String pkg = realPkg.toLowerCase(Locale.ROOT);
                if (pkg.contains("launcher") || pkg.contains("youtube")
                        || pkg.contains("settings") || pkg.contains("netflix")) {
                    continue;
                }
                String label = String.valueOf(ri.loadLabel(pm)).trim().toLowerCase(Locale.ROOT);
                for (String l : labels) {
                    if (label.equals(l)) return realPkg;
                }
                for (String k : keys) {
                    if (pkg.contains(k)) return realPkg;
                }
            }
        }
        return null;
    }
}
