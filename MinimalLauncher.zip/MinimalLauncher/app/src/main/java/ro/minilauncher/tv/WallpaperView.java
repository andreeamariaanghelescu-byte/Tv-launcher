package ro.minilauncher.tv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.view.View;

/** Fundal colorat (gradient + "pete" de culoare), desenat o singură dată la rezoluție mică. */
class WallpaperView extends View {

    // {baza1, baza2, pata1, pata2, pata3, pata4}
    static final int[][] PALETTES = {
            {0xFF0F1B4D, 0xFF3B1F6B, 0xFFFF5E8A, 0xFFFFA24C, 0xFF35C8FF, 0xFF8B5CF6},
            {0xFF2B1055, 0xFF4A6FD0, 0xFFFF7E5F, 0xFFFEB47B, 0xFFFF4E9B, 0xFF5B8DEF},
            {0xFF03256C, 0xFF1768AC, 0xFF06BEE1, 0xFF2541B2, 0xFF7AE7C7, 0xFFB38CFF},
            {0xFF3A1C71, 0xFFB5566E, 0xFFFFAF7B, 0xFFFF6FD8, 0xFF3813C2, 0xFF00E0FF},
            {0xFF0B3D3A, 0xFF134E5E, 0xFF71B280, 0xFF00D2A0, 0xFFFFD86F, 0xFF4FACFE}
    };

    private int palette = 0;
    private Bitmap bmp;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Rect dst = new Rect();

    WallpaperView(Context c) {
        super(c);
    }

    void setPalette(int i) {
        int n = PALETTES.length;
        palette = ((i % n) + n) % n;
        if (bmp != null) {
            bmp.recycle();
            bmp = null;
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (bmp == null) bmp = render(PALETTES[palette]);
        dst.set(0, 0, getWidth(), getHeight());
        canvas.drawBitmap(bmp, null, dst, paint);
    }

    private Bitmap render(int[] c) {
        int w = 640;
        int h = 360;
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        p.setShader(new LinearGradient(0, 0, w, h, c[0], c[1], Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w, h, p);

        float[][] pos = {
                {0.12f, 0.18f, 0.55f},
                {0.88f, 0.12f, 0.50f},
                {0.78f, 0.92f, 0.60f},
                {0.18f, 0.95f, 0.50f}
        };
        for (int i = 0; i < 4; i++) {
            int col = c[2 + i] & 0x00FFFFFF;
            float cx = pos[i][0] * w;
            float cy = pos[i][1] * h;
            float r = pos[i][2] * w;
            p.setShader(new RadialGradient(cx, cy, r, col | 0xB3000000, col, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, p);
        }

        // ușor întunecat, ca textul să rămână lizibil
        p.setShader(null);
        p.setColor(0x33000000);
        cv.drawRect(0, 0, w, h, p);
        return b;
    }
}
