package ro.minilauncher.tv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/** Cereri de rețea simple (vreme, clipuri YouTube, miniaturi). Se apelează doar din fire de execuție secundare. */
final class Net {
    private Net() {
    }

    static class Video {
        String id;
        String title;
    }

    private static InputStream open(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android TV) MinimalLauncher");
        return c.getInputStream();
    }

    private static String readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } finally {
            in.close();
        }
    }

    /** Întoarce {temperatura, codul vremii} de la Open-Meteo (gratuit, fără cheie API). */
    static double[] weather(double lat, double lon) throws Exception {
        String url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat
                + "&longitude=" + lon + "&current_weather=true";
        JSONObject cw = new JSONObject(readAll(open(url))).getJSONObject("current_weather");
        return new double[]{cw.getDouble("temperature"), cw.getInt("weathercode")};
    }

    static String weatherText(int c) {
        if (c == 0) return "Senin";
        if (c == 1) return "Preponderent senin";
        if (c == 2) return "Parțial noros";
        if (c == 3) return "Noros";
        if (c == 45 || c == 48) return "Ceață";
        if (c >= 51 && c <= 57) return "Burniță";
        if (c >= 61 && c <= 67) return "Ploaie";
        if (c >= 71 && c <= 77) return "Ninsoare";
        if (c >= 80 && c <= 82) return "Averse";
        if (c == 85 || c == 86) return "Averse de ninsoare";
        if (c >= 95) return "Furtună";
        return "Variabil";
    }

    /** Ultimele clipuri ale unui canal YouTube (flux RSS public). */
    static List<Video> youtube(String channelId, int max) throws Exception {
        List<Video> out = new ArrayList<Video>();
        XmlPullParser p = XmlPullParserFactory.newInstance().newPullParser();
        p.setInput(open("https://www.youtube.com/feeds/videos.xml?channel_id=" + channelId), "UTF-8");
        int ev = p.getEventType();
        Video cur = null;
        while (ev != XmlPullParser.END_DOCUMENT && out.size() < max) {
            if (ev == XmlPullParser.START_TAG) {
                String n = p.getName();
                if ("entry".equals(n)) {
                    cur = new Video();
                } else if (cur != null && "yt:videoId".equals(n)) {
                    cur.id = p.nextText();
                } else if (cur != null && "title".equals(n)) {
                    cur.title = p.nextText();
                }
            } else if (ev == XmlPullParser.END_TAG && "entry".equals(p.getName())) {
                if (cur != null && cur.id != null) out.add(cur);
                cur = null;
            }
            ev = p.next();
        }
        return out;
    }

    static Bitmap bitmap(String url) throws Exception {
        InputStream in = open(url);
        try {
            return BitmapFactory.decodeStream(in);
        } finally {
            in.close();
        }
    }
}
