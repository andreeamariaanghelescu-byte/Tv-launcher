package ro.minilauncher.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Iconițe simple desenate direct (fără fișiere externe). */
class IconView extends View {
    static final int GEAR = 0;
    static final int WIFI = 1;
    static final int WIFI_OFF = 2;
    static final int ETHERNET = 3;
    static final int PALETTE = 4;
    static final int SEARCH = 5;

    private int type = GEAR;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    IconView(Context c) {
        super(c);
    }

    void setType(int t) {
        if (t != type) {
            type = t;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float s = Math.min(w, h);
        float cx = w / 2f;
        float cy = h / 2f;

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFFFFFFFF);
        p.setStrokeWidth(s * 0.085f);

        if (type == GEAR) {
            c.drawCircle(cx, cy, s * 0.20f, p);
            p.setStrokeWidth(s * 0.13f);
            for (int i = 0; i < 8; i++) {
                double a = Math.toRadians(i * 45);
                float cs = (float) Math.cos(a);
                float sn = (float) Math.sin(a);
                c.drawLine(cx + cs * s * 0.30f, cy + sn * s * 0.30f,
                        cx + cs * s * 0.40f, cy + sn * s * 0.40f, p);
            }
        } else if (type == WIFI || type == WIFI_OFF) {
            float oy = cy + s * 0.28f;
            if (type == WIFI_OFF) p.setAlpha(110);
            for (int i = 1; i <= 3; i++) {
                float r = s * 0.16f * i;
                rect.set(cx - r, oy - r, cx + r, oy + r);
                c.drawArc(rect, -135f, 90f, false, p);
            }
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, oy, s * 0.05f, p);
            if (type == WIFI_OFF) {
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0xFFFF6B6B);
                p.setAlpha(255);
                c.drawLine(cx - s * 0.38f, cy - s * 0.36f, cx + s * 0.38f, cy + s * 0.40f, p);
            }
        } else if (type == ETHERNET) {
            rect.set(cx - s * 0.30f, cy - s * 0.34f, cx + s * 0.30f, cy + s * 0.06f);
            c.drawRoundRect(rect, s * 0.05f, s * 0.05f, p);
            for (int i = -1; i <= 1; i++) {
                float x = cx + i * s * 0.14f;
                c.drawLine(x, cy - s * 0.22f, x, cy - s * 0.08f, p);
            }
            c.drawLine(cx, cy + s * 0.06f, cx, cy + s * 0.26f, p);
            c.drawLine(cx - s * 0.22f, cy + s * 0.26f, cx + s * 0.22f, cy + s * 0.26f, p);
        } else if (type == PALETTE) {
            p.setStyle(Paint.Style.FILL);
            int[] cols = {0xFFFF5E8A, 0xFFFFA24C, 0xFF35C8FF, 0xFF8B5CF6};
            float r = s * 0.15f;
            float d = s * 0.2f;
            for (int i = 0; i < 4; i++) {
                p.setColor(cols[i]);
                float x = cx + ((i % 2 == 0) ? -d : d);
                float y = cy + ((i < 2) ? -d : d);
                c.drawCircle(x, y, r, p);
            }
        } else if (type == SEARCH) {
            c.drawCircle(cx - s * 0.07f, cy - s * 0.07f, s * 0.25f, p);
            c.drawLine(cx + s * 0.12f, cy + s * 0.12f, cx + s * 0.38f, cy + s * 0.38f, p);
        }
    }
}
